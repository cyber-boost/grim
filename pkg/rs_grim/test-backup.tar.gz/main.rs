use anyhow::{Context, Result};
use clap::{Parser, Subcommand};
use std::path::{Path, PathBuf};
use std::fs::{self, File, OpenOptions};
use std::io::{self, Read, Write, BufReader, BufWriter};
use std::collections::HashMap;
use std::process::Command;
use tokio::fs as tokio_fs;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tracing::{info, warn, error, Level};
use serde::{Deserialize, Serialize};
use chrono::{DateTime, Utc};
use uuid::Uuid;
use walkdir::WalkDir;
use flate2::write::GzEncoder;
use flate2::read::GzDecoder;
use flate2::Compression;
use tar::{Builder, Archive};
use zip::{ZipArchive, write::FileOptions};
use sha2::{Sha256, Digest};

#[derive(Parser)]
#[command(name = "grim")]
#[command(about = "Grim Reaper - High-performance backup and deployment system")]
#[command(version = "0.1.0")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Initialize a new Grim Reaper project
    Init {
        /// Project name
        #[arg(short, long)]
        name: Option<String>,

        /// Project directory
        #[arg(short, long, default_value = ".")]
        path: String,
    },

    /// Build the project
    Build {
        /// Build target (debug/release)
        #[arg(short, long, default_value = "release")]
        target: String,

        /// Clean build artifacts first
        #[arg(short, long)]
        clean: bool,
    },

    /// Deploy the project
    Deploy {
        /// Deployment environment
        #[arg(short, long, default_value = "production")]
        environment: String,

        /// Force deployment without confirmation
        #[arg(short, long)]
        force: bool,
    },

    /// Backup files and directories
    Backup {
        /// Source path to backup
        #[arg(short, long)]
        source: String,

        /// Destination path
        #[arg(short, long)]
        destination: Option<String>,

        /// Compression level (1-9)
        #[arg(short, long, default_value = "6")]
        compression: u8,
    },

    /// Restore from backup
    Restore {
        /// Backup file path
        #[arg(short, long)]
        backup: String,

        /// Destination path
        #[arg(short, long)]
        destination: String,

        /// Overwrite existing files
        #[arg(short, long)]
        overwrite: bool,
    },

    /// Show project status
    Status {
        /// Show detailed information
        #[arg(short, long)]
        verbose: bool,
    },

    /// Run tests
    Test {
        /// Test type (unit/integration/all)
        #[arg(short, long, default_value = "all")]
        test_type: String,
    },
}

#[derive(Debug, Serialize, Deserialize)]
struct ProjectConfig {
    name: String,
    version: String,
    created_at: DateTime<Utc>,
    last_backup: Option<DateTime<Utc>>,
    last_deployment: Option<DateTime<Utc>>,
    backup_count: u32,
    deployment_count: u32,
    settings: HashMap<String, String>,
}

#[derive(Debug, Serialize, Deserialize)]
struct BackupMetadata {
    id: String,
    timestamp: DateTime<Utc>,
    source_path: String,
    destination_path: String,
    compression_level: u8,
    file_count: u64,
    total_size: u64,
    checksum: String,
    format: String,
}

#[tokio::main]
async fn main() -> Result<()> {
    // Initialize tracing
    tracing_subscriber::fmt().with_max_level(Level::INFO).init();

    info!("Starting Grim Reaper...");

    let cli = Cli::parse();

    match &cli.command {
        Commands::Init { name, path } => {
            handle_init(name.as_deref(), path).await?;
        }
        Commands::Build { target, clean } => {
            handle_build(target, *clean).await?;
        }
        Commands::Deploy { environment, force } => {
            handle_deploy(environment, *force).await?;
        }
        Commands::Backup {
            source,
            destination,
            compression,
        } => {
            handle_backup(source, destination.as_deref(), *compression).await?;
        }
        Commands::Restore {
            backup,
            destination,
            overwrite,
        } => {
            handle_restore(backup, destination, *overwrite).await?;
        }
        Commands::Status { verbose } => {
            handle_status(*verbose).await?;
        }
        Commands::Test { test_type } => {
            handle_test(test_type).await?;
        }
    }

    info!("Grim Reaper completed successfully");
    Ok(())
}

async fn handle_init(name: Option<&str>, path: &str) -> Result<()> {
    info!("Initializing Grim Reaper project at: {}", path);

    let project_path = Path::new(path);
    let project_name = name.unwrap_or("grim-project");

    // Create project directory structure
    let config_dir = project_path.join(".grim");
    tokio_fs::create_dir_all(&config_dir).await
        .context("Failed to create config directory")?;

    let backups_dir = project_path.join("backups");
    tokio_fs::create_dir_all(&backups_dir).await
        .context("Failed to create backups directory")?;

    let deployments_dir = project_path.join("deployments");
    tokio_fs::create_dir_all(&deployments_dir).await
        .context("Failed to create deployments directory")?;

    // Create initial configuration
    let config = ProjectConfig {
        name: project_name.to_string(),
        version: "0.1.0".to_string(),
        created_at: Utc::now(),
        last_backup: None,
        last_deployment: None,
        backup_count: 0,
        deployment_count: 0,
        settings: HashMap::new(),
    };

    let config_file = config_dir.join("config.json");
    let config_content = serde_json::to_string_pretty(&config)
        .context("Failed to serialize config")?;
    
    tokio_fs::write(&config_file, config_content).await
        .context("Failed to write config file")?;

    // Create .gitignore
    let gitignore_content = "# Grim Reaper files\n.grim/\nbackups/\ndeployments/\n*.tar.gz\n*.zip\n*.backup\n";
    let gitignore_path = project_path.join(".gitignore");
    tokio_fs::write(&gitignore_path, gitignore_content).await
        .context("Failed to write .gitignore")?;

    println!("✅ Initialized Grim Reaper project: {project_name}");
    println!("📁 Project structure created at: {}", project_path.display());
    println!("⚙️  Configuration: {}", config_file.display());

    Ok(())
}

async fn handle_build(target: &str, clean: bool) -> Result<()> {
    info!("Building Grim Reaper project (target: {})", target);

    if clean {
        info!("Cleaning build artifacts...");
        let output = Command::new("cargo")
            .arg("clean")
            .output()
            .context("Failed to run cargo clean")?;
        
        if !output.status.success() {
            return Err(anyhow::anyhow!("Cargo clean failed: {}", String::from_utf8_lossy(&output.stderr)));
        }
    }

    let mut cmd = Command::new("cargo");
    cmd.arg("build");
    
    if target == "release" {
        cmd.arg("--release");
    }

    let output = cmd.output().context("Failed to run cargo build")?;
    
    if !output.status.success() {
        return Err(anyhow::anyhow!("Build failed: {}", String::from_utf8_lossy(&output.stderr)));
    }

    println!("✅ Build completed successfully ({target} mode)");

    Ok(())
}

async fn handle_deploy(environment: &str, force: bool) -> Result<()> {
    info!("Deploying to environment: {}", environment);

    if !force {
        println!("⚠️  Deploying to {environment} environment");
        print!("Continue? (y/N): ");
        io::stdout().flush().context("Failed to flush stdout")?;
        
        let mut input = String::new();
        io::stdin().read_line(&mut input).context("Failed to read input")?;
        
        if !input.trim().to_lowercase().starts_with('y') {
            println!("Deployment cancelled");
            return Ok(());
        }
    }

    // Simulate deployment process
    println!("🚀 Starting deployment to {environment}...");
    
    // Check if build artifacts exist
    let build_path = Path::new("target/release/grim");
    if !build_path.exists() {
        return Err(anyhow::anyhow!("Build artifacts not found. Run 'grim build' first."));
    }

    // Create deployment package
    let deployment_id = Uuid::new_v4().to_string();
    let deployment_file = format!("deployments/grim-{}-{}.tar.gz", environment, deployment_id);
    
    let file = File::create(&deployment_file)
        .context("Failed to create deployment file")?;
    let gz = GzEncoder::new(file, Compression::default());
    let mut tar = Builder::new(gz);
    
    tar.append_path_with_name(build_path, "grim")
        .context("Failed to add binary to tar")?;
    
    tar.finish().context("Failed to finish tar")?;

    // Update project config
    update_deployment_count().await?;

    println!("✅ Deployed successfully to {environment}");
    println!("📦 Deployment package: {}", deployment_file);

    Ok(())
}

async fn handle_backup(source: &str, destination: Option<&str>, compression: u8) -> Result<()> {
    info!("Backing up: {} (compression: {})", source, compression);

    let source_path = Path::new(source);
    if !source_path.exists() {
        return Err(anyhow::anyhow!("Source path does not exist: {}", source));
    }

    let dest = destination.unwrap_or("backup.tar.gz");
    let backup_path = Path::new(dest);
    
    // Create backup directory if needed
    if let Some(parent) = backup_path.parent() {
        tokio_fs::create_dir_all(parent).await
            .context("Failed to create backup directory")?;
    }

    let backup_id = Uuid::new_v4().to_string();
    let mut file_count = 0u64;
    let mut total_size = 0u64;
    let mut checksum = Sha256::new();

    // Create backup file
    let file = File::create(backup_path)
        .context("Failed to create backup file")?;
    let gz = GzEncoder::new(file, Compression::new(compression as u32));
    let mut tar = Builder::new(gz);

    // Walk through source directory
    for entry in WalkDir::new(source_path).into_iter().filter_map(|e| e.ok()) {
        let path = entry.path();
        let relative_path = path.strip_prefix(source_path)
            .context("Failed to get relative path")?;

        if path.is_file() {
            // Add file to tar
            tar.append_path_with_name(path, relative_path)
                .context("Failed to add file to tar")?;
            
            file_count += 1;
            
            // Calculate size and checksum
            let metadata = tokio_fs::metadata(path).await
                .context("Failed to get file metadata")?;
            total_size += metadata.len();
            
            let mut file_content = tokio_fs::read(path).await
                .context("Failed to read file")?;
            checksum.update(&file_content);
        }
    }

    tar.finish().context("Failed to finish tar")?;

    // Create metadata
    let metadata = BackupMetadata {
        id: backup_id,
        timestamp: Utc::now(),
        source_path: source.to_string(),
        destination_path: dest.to_string(),
        compression_level: compression,
        file_count,
        total_size,
        checksum: format!("{:x}", checksum.finalize()),
        format: "tar.gz".to_string(),
    };

    // Save metadata
    let metadata_file = format!("{}.meta", dest);
    let metadata_content = serde_json::to_string_pretty(&metadata)
        .context("Failed to serialize metadata")?;
    tokio_fs::write(&metadata_file, metadata_content).await
        .context("Failed to write metadata")?;

    // Update project config
    update_backup_count().await?;

    println!("✅ Backup completed: {source} -> {dest}");
    println!("📊 Files: {file_count}, Size: {} bytes", total_size);
    println!("🔐 Checksum: {}", metadata.checksum);

    Ok(())
}

async fn handle_restore(backup: &str, destination: &str, overwrite: bool) -> Result<()> {
    info!(
        "Restoring from: {} to: {} (overwrite: {})",
        backup, destination, overwrite
    );

    let backup_path = Path::new(backup);
    if !backup_path.exists() {
        return Err(anyhow::anyhow!("Backup file does not exist: {}", backup));
    }

    let dest_path = Path::new(destination);
    
    // Check if destination exists
    if dest_path.exists() && !overwrite {
        return Err(anyhow::anyhow!("Destination exists. Use --overwrite to force."));
    }

    // Create destination directory
    tokio_fs::create_dir_all(dest_path).await
        .context("Failed to create destination directory")?;

    // Open backup file
    let file = File::open(backup_path)
        .context("Failed to open backup file")?;
    let gz = GzDecoder::new(file);
    let mut archive = Archive::new(gz);

    let mut restored_files = 0u64;

    // Extract files
    for entry in archive.entries().context("Failed to read archive")? {
        let mut entry = entry.context("Failed to read archive entry")?;
        let path = entry.path().context("Failed to get entry path")?;
        
        let full_path = dest_path.join(path);
        
        // Create parent directories
        if let Some(parent) = full_path.parent() {
            tokio_fs::create_dir_all(parent).await
                .context("Failed to create parent directory")?;
        }

        // Extract file
        if entry.header().entry_type().is_file() {
            let mut file = File::create(&full_path)
                .context("Failed to create file")?;
            io::copy(&mut entry, &mut file)
                .context("Failed to copy file content")?;
            restored_files += 1;
        }
    }

    println!("✅ Restore completed: {backup} -> {destination}");
    println!("📁 Restored {} files", restored_files);

    Ok(())
}

async fn handle_status(verbose: bool) -> Result<()> {
    info!("Showing project status (verbose: {})", verbose);

    // Try to load project config
    let config_path = Path::new(".grim/config.json");
    let config = if config_path.exists() {
        let content = tokio_fs::read_to_string(config_path).await
            .context("Failed to read config")?;
        serde_json::from_str::<ProjectConfig>(&content)
            .context("Failed to parse config")?
    } else {
        ProjectConfig {
            name: "Unknown".to_string(),
            version: "0.1.0".to_string(),
            created_at: Utc::now(),
            last_backup: None,
            last_deployment: None,
            backup_count: 0,
            deployment_count: 0,
            settings: HashMap::new(),
        }
    };

    println!("🗡️  Grim Reaper Status");
    println!("Project: {}", config.name);
    println!("Version: {}", config.version);
    println!("Created: {}", config.created_at.format("%Y-%m-%d %H:%M:%S UTC"));
    println!("Status: ✅ Ready");

    if verbose {
        println!("Backups: {}", config.backup_count);
        println!("Deployments: {}", config.deployment_count);
        
        if let Some(last_backup) = config.last_backup {
            println!("Last backup: {}", last_backup.format("%Y-%m-%d %H:%M:%S UTC"));
        }
        
        if let Some(last_deployment) = config.last_deployment {
            println!("Last deployment: {}", last_deployment.format("%Y-%m-%d %H:%M:%S UTC"));
        }

        // Check build status
        let build_path = Path::new("target/release/grim");
        if build_path.exists() {
            let metadata = tokio_fs::metadata(build_path).await?;
            println!("Build target: release ({} bytes)", metadata.len());
        } else {
            println!("Build target: not found");
        }
    }

    Ok(())
}

async fn handle_test(test_type: &str) -> Result<()> {
    info!("Running tests (type: {})", test_type);

    let mut cmd = Command::new("cargo");
    cmd.arg("test");
    
    if test_type == "unit" {
        cmd.arg("--lib");
    } else if test_type == "integration" {
        cmd.arg("--test");
    }

    let output = cmd.output().context("Failed to run tests")?;
    
    if !output.status.success() {
        return Err(anyhow::anyhow!("Tests failed: {}", String::from_utf8_lossy(&output.stderr)));
    }

    println!("✅ All {test_type} tests passed");

    Ok(())
}

async fn update_backup_count() -> Result<()> {
    let config_path = Path::new(".grim/config.json");
    if config_path.exists() {
        let content = tokio_fs::read_to_string(config_path).await?;
        let mut config: ProjectConfig = serde_json::from_str(&content)?;
        config.backup_count += 1;
        config.last_backup = Some(Utc::now());
        
        let updated_content = serde_json::to_string_pretty(&config)?;
        tokio_fs::write(config_path, updated_content).await?;
    }
    Ok(())
}

async fn update_deployment_count() -> Result<()> {
    let config_path = Path::new(".grim/config.json");
    if config_path.exists() {
        let content = tokio_fs::read_to_string(config_path).await?;
        let mut config: ProjectConfig = serde_json::from_str(&content)?;
        config.deployment_count += 1;
        config.last_deployment = Some(Utc::now());
        
        let updated_content = serde_json::to_string_pretty(&config)?;
        tokio_fs::write(config_path, updated_content).await?;
    }
    Ok(())
}
